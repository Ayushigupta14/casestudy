package donorservices;

import java.util.ArrayList;
import java.util.Scanner;

import model.Donor;

public class DonorServices {
	
	public static void addDonor(Donor obj)
	{
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter details");
//		String name=sc.nextLine();
//		String email=sc.nextLine();
//		String mobile=sc.nextLine();
//		String password=sc.nextLine();
//		
//		double age=sc.nextDouble();
//		sc.nextLine();
//		String gender=sc.nextLine();
//		String bloodGroup=sc.nextLine();
//			
//		
//		String city=sc.nextLine();
//		String state=sc.nextLine();
//		System.out.println("Done");
//		Donor obj=new Donor(name,email,mobile,password,age,gender,bloodGroup,city,state);
//		sc.close();
		
		DonorDatabase.add(obj);
	}
	
	public static ArrayList<Donor> getAll(){
		return DonorDatabase.getAll();
	}
	
	public static ArrayList<Donor> findDonor(Donor obj){
		return DonorDatabase.findDonor(obj.getCity(),obj.getState(),obj.getBloodGroup());
	} 

}
