package donorservices;

import java.util.Iterator;
import java.util.ArrayList;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;

import databaseconnection.DatabaseConnection;

import model.Donor;

public class DonorDatabase {
	
	static MongoCollection<Document> dCollection;
	static {
		dCollection=DatabaseConnection.getDonorCollection();
	}
	
	public static void add(Donor donor)
	{
		Document toAdd=DonorAdapter.toDocument(donor);
		dCollection.insertOne(toAdd);
	}
	
	public static ArrayList<Donor> getAll()
	{
		ArrayList<Donor> al=new ArrayList<Donor>();
		FindIterable<Document> fit=dCollection.find();
		
		Iterator<Document> it= fit.iterator();
		while(it.hasNext())
		{
			
			Document doc=it.next();
			al.add(DonorAdapter.toDonorObject(doc));
			System.out.println(doc);
		}
		return al;
	}
	
	public static ArrayList<Donor> findDonor(String city,String state,String bloodGroup)
	{
		ArrayList<Donor> al=new ArrayList<Donor>();
		
		FindIterable<Document> fit=dCollection.find(Filters.and(Filters.eq("city", city),
				Filters.eq("state",state ),Filters.eq("blood group", bloodGroup)));
		
		Iterator<Document> it= fit.iterator();
		while(it.hasNext())
		{
			
			Document doc=it.next();
			al.add(DonorAdapter.toDonorObject(doc));
			System.out.println(doc);
		}
		return al;
	}
	
	

}
