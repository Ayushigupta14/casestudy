package services;

public class DonorAdapter {

}
