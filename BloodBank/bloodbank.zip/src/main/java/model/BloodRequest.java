package model;

public class BloodRequest {
	
	private String username;
	private String name;
	private String mobile;
	private String bloodGroup;
	private String area;
	private String city;
	private String state;
	private String country;
	
	public BloodRequest(String username, String name,String mobile,
			String bloodGroup, String area,String city,String state,
			String country)
	{
		this.username=username;
		this.name=name;
		this.mobile=mobile;
		this.area=area;
		this.city=city;
		this.state=state;
		this.country=country;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}

	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	

}
