package model;

public class Donor {
	
	private String name;
	private String username;
	private String email;
	private double age;
	private String gender;
	private String bloodGroup;
	private String password;
	private String mobile;
	private String residenceNo;
	private String officeNo;
	private String address;
	private String city;
	private String state;
	private String area;
	private String country;
	
	public Donor()
	{
		
	}

	public Donor(String name,String username, String email,String password,
			double age, String gender,String bloodGroup, String mobile,
			String residenceNo,String officeNo,String address,String area,
			String city,String state, String country)
	{
		this.name=name;
		this.username=username;
		this.email=email;
		this.password=password;
		this.age=age;
		this.gender=gender;
		this.bloodGroup=bloodGroup;
		this.mobile=mobile;
		this.residenceNo=residenceNo;
		this.officeNo=officeNo;
		this.address=address;
		this.area=area;
		this.city=city;
		this.state=state;
		this.country=country;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public double getAge() {
		return age;
	}
	public void setAge(double age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getResidenceNo() {
		return residenceNo;
	}
	public void setResidenceNo(String residenceNo) {
		this.residenceNo = residenceNo;
	}

	public String getOfficeNo() {
		return officeNo;
	}
	public void setOfficeNo(String officeNo) {
		this.officeNo = officeNo;
	}

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}

	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	
}
